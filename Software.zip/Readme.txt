# Contains scripts NPFCMselection.R
# NPFCM_selection.html illustrates a demonstration of the proposed method 
# bikenp.csv contains the bike sharing data
# Function implenting NPFCM selection method
#########################################################
# @ y= response                      
# @ mydata = a dataframe in long format column 1=id, column 2 = time, rest covariates
# @ basist = Number of basis functions in t direction.
# @ basisx = Number of basis functions in x direction. 
#########################################################
NPFCM.select(y,mydata,basist=c(4:10),basisx=c(4:10))
#########################################################
# Function implenting preprocessing covariates for NPFCM selection method
#########################################################
# @ mydata = a dataframe in long format column 1=id, column 2 = time, rest covariates
#########################################################
pprocess(mydata)